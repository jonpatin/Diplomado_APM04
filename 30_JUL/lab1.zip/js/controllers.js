angular.module('app.controllers', [])
  
.controller('buttonsCtrl', function($scope) {

})
   
.controller('listCtrl', function($scope) {

})
   
.controller('cardsCtrl', function($scope) {

})
 