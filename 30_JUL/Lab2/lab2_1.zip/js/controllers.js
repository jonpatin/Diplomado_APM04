angular.module('app.controllers', [])
  
.controller('homeCtrl', function($scope) {

})
   
.controller('listCtrl', function($scope) {

})
   
.controller('toggleCtrl', function($scope) {

})
   
.controller('formsCtrl', function($scope) {

})
 