angular.module('app.controllers', [])
  
.controller('loginCtrl', function($scope) {

})
   
.controller('pageCtrl', function($scope) {

})
 