angular.module('app.controllers', [])
  
.controller('cameraTabDefaultPageCtrl', function($scope) {

})
   
.controller('cartTabDefaultPageCtrl', function($scope) {

})
   
.controller('cloudTabDefaultPageCtrl', function($scope) {

})
    